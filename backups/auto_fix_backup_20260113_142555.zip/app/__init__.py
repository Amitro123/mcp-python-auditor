"""Initialize app package."""
