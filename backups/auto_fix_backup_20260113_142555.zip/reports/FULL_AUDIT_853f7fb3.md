# Full Code Audit Report
**Project:** mcp-python-auditor
**Date:** 2026-01-13 12:08
**Scan Duration:** 266.21s
**Job ID:** 853f7fb3
**Self-Healing:** Auto-installed bandit, pip-audit

---

## Project Overview

- **Python Files:** 2539
- **Total Lines:** 29814
- **Git Branch:** main
- **Last Commit:** fix: ReportGenerator Bandit display - extract from (15 hours ago)

## Summary

| Tool | Status | Issues |
|------|--------|--------|
| Bandit (Security) | error | 0 |
| Secrets | clean | 0 |
| Ruff (Quality) | clean | 0 |
| Pip-Audit (Deps) | error | 0 |
| Dead Code | issues_found | 5 |
| Complexity (Radon) | issues_found | 29 |
| Cleanup | cleanup_available | 62.67 MB |
| Tests & Coverage | success | 34% |

## Security Issues (Bandit)

No security issues found.

## Secrets Detection

No hardcoded secrets found.

## Code Quality (Ruff)

No linting issues found.

## Dead Code (Vulture)

Found 5 unused code items:

- app\core\report_generator.py:12: unused import '_write_security_section' (90% confidence)
- app\main.py:12: unused import 'ReportResponse' (90% confidence)
- app\schemas.py:16: unused variable 'cls' (100% confidence)
- app\schemas.py:62: unused variable 'cls' (100% confidence)
- mcp_fastmcp_server.py:1042: unused variable 'dir' (100% confidence)

## High Complexity Functions (Radon)

| File | Function | Complexity | Grade |
|------|----------|------------|-------|
| `mcp_fastmcp_server.py` | generate_full_markdown_report | 33 | **E** |
| `mcp_fastmcp_server.py` | run_architecture_visualizer | 22 | **D** |
| `mcp_fastmcp_server.py` | run_auto_fix | 19 | **C** |
| `mcp_fastmcp_server.py` | run_cleanup_scan | 14 | **C** |
| `mcp_fastmcp_server.py` | run_tests_coverage | 14 | **C** |
| `mcp_fastmcp_server.py` | run_pip_audit | 12 | **C** |
| `mcp_fastmcp_server.py` | run_efficiency | 11 | **C** |
| `self_audit.py` | run_self_audit | 16 | **C** |
| `validate_dataset.py` | validate_dataset | 23 | **D** |
| `analyzer_agent.py` | _calculate_score | 21 | **D** |
| `analyzer_agent.py` | analyze_project | 18 | **C** |
| `report_generator.py` | _write_top_issues_summary | 18 | **C** |
| `report_generator.py` | _write_enterprise_tests | 16 | **C** |
| `report_generator.py` | _write_top_action_roadmap | 13 | **C** |
| `report_generator.py` | _write_self_healing_section | 11 | **C** |

## Vulnerable Dependencies (Pip-Audit)

No vulnerable dependencies found.

## Cleanup Opportunities

**62.67 MB** can be cleaned up:

- `__pycache__`: 301 items
- `.pytest_cache`: 1 items
- `htmlcov`: 1 items
- `*.pyc`: 2553 items

## Tests & Coverage

**Total Coverage:** 34%
**Tests Passed:** 26
**Tests Failed:** 2
**Test Files:** 14

## Architecture Visualization

**Files analyzed:** 45
**Internal dependencies:** 50

```mermaid
graph TD
    demo_autofix[demo_autofix] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> fastmcp[fastmcp]
    mcp_fastmcp_server[mcp_fastmcp_server] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> ast[ast]
    mcp_server[mcp_server] --> app[app]
    self_audit[self_audit] --> app[app]
    test_direct[test_direct] --> app[app]
    test_mcp_tools[test_mcp_tools] --> app[app]
    app_main[app/main] --> fastapi[fastapi]
    app_main[app/main] --> app[app]
    app_main[app/main] --> uvicorn[uvicorn]
    app_schemas[app/schemas] --> pydantic[pydantic]
    tests_conftest[tests/conftest] --> pytest[pytest]
    tests_conftest[tests/conftest] --> app[app]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> pytest[pytest]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> app[app]
    tests_test_api[tests/test_api] --> pytest[pytest]
    tests_test_api[tests/test_api] --> fastapi[fastapi]
    tests_test_api[tests/test_api] --> app[app]
    tests_test_parallel_audit[tests/test_parallel_audit] --> pytest[pytest]
    tests_test_parallel_audit[tests/test_parallel_audit] --> app[app]
    tests_test_tools[tests/test_tools] --> pytest[pytest]
    tests_test_tools[tests/test_tools] --> app[app]
    tests_test_tool_fixes[tests/test_tool_fixes] --> pytest[pytest]
    tests_test_tool_fixes[tests/test_tool_fixes] --> app[app]
    app_agents_analyzer_agent[app/agents/analyzer_agent] --> app[app]
    app_core_config[app/core/config] --> yaml[yaml]
    app_core_config[app/core/config] --> app[app]
    app_core_config[app/core/config] --> tomllib[tomllib]
    app_core_config[app/core/config] --> tomli[tomli]
    app_core_fix_orchestrator[app/core/fix_orchestrator] --> app[app]
    app_core_report_generator[app/core/report_generator] --> app[app]
    app_core_tool_registry[app/core/tool_registry] --> app[app]
    app_tools_architecture_tool[app/tools/architecture_tool] --> ast[ast]
    app_tools_architecture_tool[app/tools/architecture_tool] --> app[app]
    app_tools_cleanup_tool[app/tools/cleanup_tool] --> app[app]
    app_tools_complexity_tool[app/tools/complexity_tool] --> app[app]
    app_tools_deadcode_tool[app/tools/deadcode_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> ast[ast]
    app_tools_duplication_tool[app/tools/duplication_tool] --> rapidfuzz[rapidfuzz]
    app_tools_duplication_tool[app/tools/duplication_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> astor[astor]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> ast[ast]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> app[app]
    app_tools_gitignore_tool[app/tools/gitignore_tool] --> app[app]
    app_tools_git_tool[app/tools/git_tool] --> app[app]
    app_tools_secrets_tool[app/tools/secrets_tool] --> app[app]
    app_tools_security_tool[app/tools/security_tool] --> app[app]
    app_tools_structure_tool[app/tools/structure_tool] --> app[app]
    app_tools_tests_tool[app/tools/tests_tool] --> app[app]
```

---
*Generated by Python Auditor MCP Server*