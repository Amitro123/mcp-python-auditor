# Full Code Audit Report
**Project:** mcp-python-auditor
**Date:** 2026-01-13 11:25
**Scan Duration:** 91.14s
**Job ID:** 9f015bdb

---

## Project Overview

- **Python Files:** 2539
- **Total Lines:** 29531
- **Git Branch:** main
- **Last Commit:** fix: ReportGenerator Bandit display - extract from (15 hours ago)

## Summary

| Tool | Status | Issues |
|------|--------|--------|
| Bandit (Security) | error | 0 |
| Secrets | error | 0 |
| Ruff (Quality) | clean | 0 |
| Pip-Audit (Deps) | error | 0 |
| Dead Code | issues_found | 160 |
| Complexity (Radon) | issues_found | 27 |
| Cleanup | cleanup_available | 62.65 MB |

## Security Issues (Bandit)

No security issues found.

## Secrets Detection

No hardcoded secrets found.

## Code Quality (Ruff)

No linting issues found.

## Dead Code (Vulture)

Found 30 unused code items:

- .venv\Lib\site-packages\_pytest\hookspec.py:1038: unused variable 'startdir' (100% confidence)
- .venv\Lib\site-packages\_pytest\hookspec.py:1076: unused variable 'startdir' (100% confidence)
- .venv\Lib\site-packages\_pytest\python_api.py:35: unused variable 'full_object' (100% confidence)
- .venv\Lib\site-packages\annotated_types\__init__.py:69: unused variable '__other' (100% confidence)
- .venv\Lib\site-packages\annotated_types\__init__.py:74: unused variable '__other' (100% confidence)
- .venv\Lib\site-packages\annotated_types\__init__.py:79: unused variable '__other' (100% confidence)
- .venv\Lib\site-packages\annotated_types\__init__.py:84: unused variable '__other' (100% confidence)
- .venv\Lib\site-packages\annotated_types\__init__.py:89: unused variable '__other' (100% confidence)
- .venv\Lib\site-packages\annotated_types\__init__.py:94: unused variable '__other' (100% confidence)
- .venv\Lib\site-packages\authlib\oauth2\rfc7523\client.py:99: unused variable 'jti' (100% confidence)
- .venv\Lib\site-packages\authlib\oauth2\rfc9068\token.py:162: unsatisfiable 'if' condition (100% confidence)
- .venv\Lib\site-packages\cffi\backend_ctypes.py:54: unused variable 'ctypes_value' (100% confidence)
- .venv\Lib\site-packages\cffi\backend_ctypes.py:984: unused variable 'bptr' (100% confidence)
- .venv\Lib\site-packages\click\core.py:1633: unused variable '__func' (100% confidence)
- .venv\Lib\site-packages\click\core.py:1682: unused variable '__func' (100% confidence)

*...and 15 more*

## High Complexity Functions (Radon)

| File | Function | Complexity | Grade |
|------|----------|------------|-------|
| `mcp_fastmcp_server.py` | generate_full_markdown_report | 28 | **D** |
| `mcp_fastmcp_server.py` | run_architecture_visualizer | 22 | **D** |
| `mcp_fastmcp_server.py` | run_auto_fix | 21 | **D** |
| `mcp_fastmcp_server.py` | run_cleanup_scan | 14 | **C** |
| `mcp_fastmcp_server.py` | run_efficiency | 11 | **C** |
| `self_audit.py` | run_self_audit | 16 | **C** |
| `validate_dataset.py` | validate_dataset | 23 | **D** |
| `analyzer_agent.py` | _calculate_score | 21 | **D** |
| `analyzer_agent.py` | analyze_project | 18 | **C** |
| `report_generator.py` | _write_top_issues_summary | 18 | **C** |
| `report_generator.py` | _write_enterprise_tests | 16 | **C** |
| `report_generator.py` | _write_top_action_roadmap | 13 | **C** |
| `report_generator.py` | _write_self_healing_section | 11 | **C** |
| `report_generator.py` | _write_mandatory_deadcode | 11 | **C** |
| `report_sections.py` | _write_security_section | 17 | **C** |

## Vulnerable Dependencies (Pip-Audit)

No vulnerable dependencies found.

## Cleanup Opportunities

**62.65 MB** can be cleaned up:

- `__pycache__`: 301 items
- `.pytest_cache`: 1 items
- `htmlcov`: 1 items
- `*.pyc`: 2553 items

## Architecture Visualization

**Files analyzed:** 45
**Internal dependencies:** 50

```mermaid
graph TD
    demo_autofix[demo_autofix] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> fastmcp[fastmcp]
    mcp_fastmcp_server[mcp_fastmcp_server] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> ast[ast]
    mcp_server[mcp_server] --> app[app]
    self_audit[self_audit] --> app[app]
    test_direct[test_direct] --> app[app]
    test_mcp_tools[test_mcp_tools] --> app[app]
    app_main[app/main] --> fastapi[fastapi]
    app_main[app/main] --> app[app]
    app_main[app/main] --> uvicorn[uvicorn]
    app_schemas[app/schemas] --> pydantic[pydantic]
    tests_conftest[tests/conftest] --> pytest[pytest]
    tests_conftest[tests/conftest] --> app[app]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> pytest[pytest]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> app[app]
    tests_test_api[tests/test_api] --> pytest[pytest]
    tests_test_api[tests/test_api] --> fastapi[fastapi]
    tests_test_api[tests/test_api] --> app[app]
    tests_test_parallel_audit[tests/test_parallel_audit] --> pytest[pytest]
    tests_test_parallel_audit[tests/test_parallel_audit] --> app[app]
    tests_test_tools[tests/test_tools] --> pytest[pytest]
    tests_test_tools[tests/test_tools] --> app[app]
    tests_test_tool_fixes[tests/test_tool_fixes] --> pytest[pytest]
    tests_test_tool_fixes[tests/test_tool_fixes] --> app[app]
    app_agents_analyzer_agent[app/agents/analyzer_agent] --> app[app]
    app_core_config[app/core/config] --> yaml[yaml]
    app_core_config[app/core/config] --> app[app]
    app_core_config[app/core/config] --> tomllib[tomllib]
    app_core_config[app/core/config] --> tomli[tomli]
    app_core_fix_orchestrator[app/core/fix_orchestrator] --> app[app]
    app_core_report_generator[app/core/report_generator] --> app[app]
    app_core_tool_registry[app/core/tool_registry] --> app[app]
    app_tools_architecture_tool[app/tools/architecture_tool] --> ast[ast]
    app_tools_architecture_tool[app/tools/architecture_tool] --> app[app]
    app_tools_cleanup_tool[app/tools/cleanup_tool] --> app[app]
    app_tools_complexity_tool[app/tools/complexity_tool] --> app[app]
    app_tools_deadcode_tool[app/tools/deadcode_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> ast[ast]
    app_tools_duplication_tool[app/tools/duplication_tool] --> rapidfuzz[rapidfuzz]
    app_tools_duplication_tool[app/tools/duplication_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> astor[astor]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> ast[ast]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> app[app]
    app_tools_gitignore_tool[app/tools/gitignore_tool] --> app[app]
    app_tools_git_tool[app/tools/git_tool] --> app[app]
    app_tools_secrets_tool[app/tools/secrets_tool] --> app[app]
    app_tools_security_tool[app/tools/security_tool] --> app[app]
    app_tools_structure_tool[app/tools/structure_tool] --> app[app]
    app_tools_tests_tool[app/tools/tests_tool] --> app[app]
```

---
*Generated by Python Auditor MCP Server*