# 🕵️‍♂️ Project Audit Report: mcp-python-auditor
**Score:** 90/100 🟢 | **Date:** 2026-01-13 13:46
**Scan Duration:** 73.29s | **Job ID:** `6e6f0d6c`

## 🔧 Self-Healing Status
**Status:** Healthy ✅ (No missing tools detected)

## 🚨 Top Priorities
1. 🟡 **Testing:** Very low coverage (33%)

## 📂 Project Structure
**Files:** 2540 Python | **Lines:** 0
### 📁 Tree View
```
├── 📁 app
│   ├── 📁 agents
│   │   ├── 🐍 __init__.py
│   │   └── 🐍 analyzer_agent.py
│   ├── 📁 core
│   │   ├── 🐍 __init__.py
│   │   ├── 🐍 base_tool.py
│   │   ├── 🐍 config.py
│   │   ├── 🐍 fix_orchestrator.py
│   │   ├── 🐍 report_generator.py
│   │   ├── 📄 report_generator.py.bak
│   │   ├── 🐍 report_sections.py
│   │   ├── 🐍 self_healing.py
│   │   ├── 🐍 subprocess_wrapper.py
│   │   └── 🐍 tool_registry.py
│   ├── 📁 tools
│   │   ├── 🐍 __init__.py
│   │   ├── 🐍 architecture_tool.py
│   │   ├── 🐍 cleanup_tool.py
│   │   ├── 📄 cleanup_tool.py.bak
│   │   ├── 🐍 code_editor_tool.py
│   │   ├── 🐍 complexity_tool.py
│   │   ├── 🐍 deadcode_tool.py
│   │   ├── 🐍 duplication_tool.py
│   │   ├── 🐍 efficiency_tool.py
│   │   ├── 🐍 git_tool.py
│   │   ├── 🐍 gitignore_tool.py
│   │   ├── 🐍 secrets_tool.py
│   │   ├── 🐍 security_tool.py
│   │   ├── 🐍 structure_tool.py
│   │   ├── 🐍 tests_tool.py
│   │   └── 🐍 typing_tool.py
│   ├── 🐍 __init__.py
│   ├── 🐍 main.py
│   ├── 📄 main.py.bak
│   └── 🐍 schemas.py
├── 📁 data
│   ├── 📄 README_DATASET.md
│   ├── 📄 audit_dataset.jsonl
│   ├── 📄 audit_dataset_500.jsonl
│   └── 📄 audit_dataset_fixed.jsonl
├── 📁 finetune
│   ├── 🐍 fix_notebook.py
│   └── 📄 kaggle_finetune.ipynb
├── 📁 fresh-install-test
├── 📁 tests
│   ├── 🐍 __init__.py
│   ├── 🐍 conftest.py
│   ├── 🐍 test_analyzer_agent.py
│   ├── 🐍 test_api.py
│   ├── 🐍 test_parallel_audit.py
│   ├── 🐍 test_tool_fixes.py
│   └── 🐍 test_tools.py
├── 📄 AMIT_CODING_PREFERENCES.md
├── 📄 AUTOFIX_GUIDE.md
├── 📄 AUTOFIX_QUICK_REF.md
├── 📄 BEFORE_AFTER_COMPARISON.md
├── 📄 CENTRALIZED_EXCLUSIONS_COMPLETE.md
├── 📄 CHANGES_TRACKER.md
├── 📄 Dockerfile
├── 📄 FULL_VISIBILITY_REFACTOR.md
├── 📄 IMPLEMENTATION_SUMMARY.md
├── 📄 INTEGRATION_GUIDE.md
├── 📄 MCP_INTEGRATION.md
├── 📄 PRODUCTION_REFINEMENTS.md
├── 📄 QUICK_MCP_SETUP.md
├── 📄 QUICK_REFERENCE_GUIDE.md
├── 📄 README.md
├── 📄 SELF_AUDIT_REPORT.md
├── 📄 SESSION_SUMMARY.md
├── 📄 SMART_ROOT_DETECTION.md
├── 📄 SMART_ROOT_VISUAL_COMPARISON.md
├── 📄 audit.yaml.example
├── 🐍 dataset_templates.py
├── 📄 debug_audit.txt
├── 🐍 demo_autofix.py
├── 📄 docker-compose.yml
├── 🐍 duplication_helper.py
├── 🐍 mcp_fastmcp_server.py
├── 🐍 mcp_server.py
├── 📄 pyproject.toml
├── 📄 requirements.txt
├── 🐍 self_audit.py
├── 📄 self_audit.py.bak
├── 🐍 test_direct.py
├── 🐍 test_mcp_tools.py
└── 🐍 validate_dataset.py
```

## 🗺️ Architecture Logic
```mermaid
graph TD
    demo_autofix[demo_autofix] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> fastmcp[fastmcp]
    mcp_fastmcp_server[mcp_fastmcp_server] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> ast[ast]
    mcp_server[mcp_server] --> app[app]
    self_audit[self_audit] --> app[app]
    test_direct[test_direct] --> app[app]
    test_mcp_tools[test_mcp_tools] --> app[app]
    app_main[app/main] --> fastapi[fastapi]
    app_main[app/main] --> app[app]
    app_main[app/main] --> uvicorn[uvicorn]
    app_schemas[app/schemas] --> pydantic[pydantic]
    tests_conftest[tests/conftest] --> pytest[pytest]
    tests_conftest[tests/conftest] --> app[app]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> pytest[pytest]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> app[app]
    tests_test_api[tests/test_api] --> pytest[pytest]
    tests_test_api[tests/test_api] --> fastapi[fastapi]
    tests_test_api[tests/test_api] --> app[app]
    tests_test_parallel_audit[tests/test_parallel_audit] --> pytest[pytest]
    tests_test_parallel_audit[tests/test_parallel_audit] --> app[app]
    tests_test_tools[tests/test_tools] --> pytest[pytest]
    tests_test_tools[tests/test_tools] --> app[app]
    tests_test_tool_fixes[tests/test_tool_fixes] --> pytest[pytest]
    tests_test_tool_fixes[tests/test_tool_fixes] --> app[app]
    app_agents_analyzer_agent[app/agents/analyzer_agent] --> app[app]
    app_core_config[app/core/config] --> yaml[yaml]
    app_core_config[app/core/config] --> app[app]
    app_core_config[app/core/config] --> tomllib[tomllib]
    app_core_config[app/core/config] --> tomli[tomli]
    app_core_fix_orchestrator[app/core/fix_orchestrator] --> app[app]
    app_core_report_generator[app/core/report_generator] --> app[app]
    app_core_tool_registry[app/core/tool_registry] --> app[app]
    app_tools_architecture_tool[app/tools/architecture_tool] --> ast[ast]
    app_tools_architecture_tool[app/tools/architecture_tool] --> app[app]
    app_tools_cleanup_tool[app/tools/cleanup_tool] --> app[app]
    app_tools_complexity_tool[app/tools/complexity_tool] --> app[app]
    app_tools_deadcode_tool[app/tools/deadcode_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> ast[ast]
    app_tools_duplication_tool[app/tools/duplication_tool] --> rapidfuzz[rapidfuzz]
    app_tools_duplication_tool[app/tools/duplication_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> astor[astor]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> ast[ast]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> app[app]
    app_tools_gitignore_tool[app/tools/gitignore_tool] --> app[app]
    app_tools_git_tool[app/tools/git_tool] --> app[app]
    app_tools_secrets_tool[app/tools/secrets_tool] --> app[app]
    app_tools_security_tool[app/tools/security_tool] --> app[app]
    app_tools_structure_tool[app/tools/structure_tool] --> app[app]
    app_tools_tests_tool[app/tools/tests_tool] --> app[app]
```
[🔍 **Open Interactive Graph**](https://mermaid.live/edit#pako:eNqtV81u5CAMfpUo563mvoc97SP0xlaIJU5qiQACUnWm6rsvkEwD-c9sIyUYm--zATshHyVXFZQ_i7IxTL8Wz7__yMJfFbSKss6pGt9J2nkpnp5-FUxr4u-XfnDLNa2ZdaG1YN7AkLmqBw46MrTnCR727FXE3wkwAax7sCBqP_cKHRnFpYEOrKMVGuCOJPLq0ODWKSUsybtLAC_RlqEMqksQxsVkGsnQbg8-xNi9IVdGkqFNBlv-Ci2zcfwg9xB9rZh0yMldSCZpKVeyDlKcpL3cu3doNPXNcdh8MS2Na8gkE9cbGMoakHfsgmXP-wNk6zH5_UmxfpsOeV-BLW_5AeBqgJoZJgSIIckTbG45FPY5stWYxroY0Ell7ESwBd30R_3LDWbIXnvY8z7JvAxjFtlpvoU66y2X_XwLNL5eIdYNNhEc-pe-30OurBUkPM6AHvDjVCsE_iVDexaKEYhTmF9Cqox_8VhnmFNmJJhaNgM3oJVx1C8kTGimlk2auKsGGvQ-ryNHpl4jiAlJmY8Ynf9AdANdZIm2y8y29AX7P6qVqLgAJjs9ZUnVOwSq1QLe0V1nHLllm6YCVoWDyZQk0-9QdFogZw6VnLFMTNvLe5rIH6SwqrvbjXxJ3xDdN04zpH14zsigrpEjSD7bvYlle8XO0qxMrUGHjVTzpM4NuyQL8ANAC9xAeLfn4FS9S9CZhULI9DsUznSLZZ0btkmGT1ROMCpzcPmjKFsw_kRY-Z-Cj9L5k178PaigZp1w5efnP7RphZk=)

## 📊 Detailed Findings
### 🛡️ Security (0 issues)
✅ No security issues found.

### 🧹 Code Quality & Hygiene
**💀 Dead Code / Unused (5 items)**
- `app\core\report_generator.py:12: unused import '_write_security_section' (90% confidence)`
- `app\main.py:12: unused import 'ReportResponse' (90% confidence)`
- `app\schemas.py:16: unused variable 'cls' (100% confidence)`
- `app\schemas.py:62: unused variable 'cls' (100% confidence)`
- `mcp_fastmcp_server.py:1187: unused variable 'dir' (100% confidence)`

**🤯 Complex Functions (Radon)**
| File | Function | Rank | Score |
|---|---|---|---|
| duplication_helper.py | run_duplication | C | 16 |
| mcp_fastmcp_server.py | generate_full_markdown_report | D | 27 |
| mcp_fastmcp_server.py | run_architecture_visualizer | D | 22 |
| mcp_fastmcp_server.py | run_auto_fix | C | 19 |
| mcp_fastmcp_server.py | run_duplication | C | 16 |
| mcp_fastmcp_server.py | run_tests_coverage | C | 15 |
| mcp_fastmcp_server.py | run_cleanup_scan | C | 14 |
| mcp_fastmcp_server.py | run_pip_audit | C | 13 |
| mcp_fastmcp_server.py | run_efficiency | C | 12 |
| mcp_fastmcp_server.py | run_secrets | C | 11 |
| mcp_fastmcp_server.py | run_dead_code | C | 11 |
| self_audit.py | run_self_audit | C | 16 |
| validate_dataset.py | validate_dataset | D | 23 |
| analyzer_agent.py | _calculate_score | D | 21 |
| analyzer_agent.py | analyze_project | C | 18 |
| report_generator.py | _write_top_issues_summary | C | 18 |
| report_generator.py | _write_enterprise_tests | C | 16 |
| report_generator.py | _write_top_action_roadmap | C | 13 |
| report_generator.py | _write_self_healing_section | C | 11 |
| report_generator.py | _write_mandatory_deadcode | C | 11 |

## 🎭 DUPLICATES (Grouped + Actionable)
**Found 6383 duplicated blocks.**
- **Hash:** `81e85647` (51 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:75`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:195`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:830`
  - ...and 2 more
- **Hash:** `4a572b0a` (39 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:66`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:185`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:263`
  - ...and 2 more
- **Hash:** `6f95a3f5` (39 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:67`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:186`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:264`
  - ...and 2 more
- **Hash:** `881acf70` (38 copies)
  - `.venv\Lib\site-packages\fastapi\applications.py:734`
  - `.venv\Lib\site-packages\fastapi\applications.py:1267`
  - `.venv\Lib\site-packages\fastapi\applications.py:1551`
  - ...and 2 more
- **Hash:** `7b60e182` (35 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:76`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:196`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:831`
  - ...and 2 more

**🗑️ Junk / Cleanup**
- **Total Reclaimable:** 64.98 MB
  - `__pycache__`: 301 items
  - `.pytest_cache`: 1 items
  - `htmlcov`: 1 items
  - `*.pyc`: 2612 items

### 🧪 Tests & Coverage
- **Coverage:** 33%
- **Passed:** 26 ✅
- **Failed:** 2 ❌

---
*Generated by Python Auditor MCP v2.1*