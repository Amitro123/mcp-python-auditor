# 🕵️‍♂️ Project Audit Report: mcp-python-auditor
**Score:** 90/100 🟢 | **Date:** 2026-01-13 13:23
**Scan Duration:** 62.41s | **Job ID:** `ed04e765`

## 🔧 Self-Healing Status
**Status:** Healthy ✅ (No missing tools detected)

## 🚨 Top Priorities
1. 🟡 **Testing:** Very low coverage (34%)

## 📂 Project Structure
**Files:** 2539 Python | **Lines:** 29815
### Top Directories
- `/app`
- `/data`
- `/finetune`
- `/fresh-install-test`
- `/htmlcov`
- `/reports`
- `/tests`
- `/__pycache__`

## 🗺️ Architecture Logic
```mermaid
graph TD
    demo_autofix[demo_autofix] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> fastmcp[fastmcp]
    mcp_fastmcp_server[mcp_fastmcp_server] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> ast[ast]
    mcp_server[mcp_server] --> app[app]
    self_audit[self_audit] --> app[app]
    test_direct[test_direct] --> app[app]
    test_mcp_tools[test_mcp_tools] --> app[app]
    app_main[app/main] --> fastapi[fastapi]
    app_main[app/main] --> app[app]
    app_main[app/main] --> uvicorn[uvicorn]
    app_schemas[app/schemas] --> pydantic[pydantic]
    tests_conftest[tests/conftest] --> pytest[pytest]
    tests_conftest[tests/conftest] --> app[app]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> pytest[pytest]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> app[app]
    tests_test_api[tests/test_api] --> pytest[pytest]
    tests_test_api[tests/test_api] --> fastapi[fastapi]
    tests_test_api[tests/test_api] --> app[app]
    tests_test_parallel_audit[tests/test_parallel_audit] --> pytest[pytest]
    tests_test_parallel_audit[tests/test_parallel_audit] --> app[app]
    tests_test_tools[tests/test_tools] --> pytest[pytest]
    tests_test_tools[tests/test_tools] --> app[app]
    tests_test_tool_fixes[tests/test_tool_fixes] --> pytest[pytest]
    tests_test_tool_fixes[tests/test_tool_fixes] --> app[app]
    app_agents_analyzer_agent[app/agents/analyzer_agent] --> app[app]
    app_core_config[app/core/config] --> yaml[yaml]
    app_core_config[app/core/config] --> app[app]
    app_core_config[app/core/config] --> tomllib[tomllib]
    app_core_config[app/core/config] --> tomli[tomli]
    app_core_fix_orchestrator[app/core/fix_orchestrator] --> app[app]
    app_core_report_generator[app/core/report_generator] --> app[app]
    app_core_tool_registry[app/core/tool_registry] --> app[app]
    app_tools_architecture_tool[app/tools/architecture_tool] --> ast[ast]
    app_tools_architecture_tool[app/tools/architecture_tool] --> app[app]
    app_tools_cleanup_tool[app/tools/cleanup_tool] --> app[app]
    app_tools_complexity_tool[app/tools/complexity_tool] --> app[app]
    app_tools_deadcode_tool[app/tools/deadcode_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> ast[ast]
    app_tools_duplication_tool[app/tools/duplication_tool] --> rapidfuzz[rapidfuzz]
    app_tools_duplication_tool[app/tools/duplication_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> astor[astor]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> ast[ast]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> app[app]
    app_tools_gitignore_tool[app/tools/gitignore_tool] --> app[app]
    app_tools_git_tool[app/tools/git_tool] --> app[app]
    app_tools_secrets_tool[app/tools/secrets_tool] --> app[app]
    app_tools_security_tool[app/tools/security_tool] --> app[app]
    app_tools_structure_tool[app/tools/structure_tool] --> app[app]
    app_tools_tests_tool[app/tools/tests_tool] --> app[app]
```

## 📊 Detailed Findings
### 🛡️ Security (0 issues)
✅ No security issues found.

### 🧹 Code Quality & Hygiene
**💀 Dead Code / Unused (5 items)**
- `app\core\report_generator.py:12: unused import '_write_security_section' (90% confidence)`
- `app\main.py:12: unused import 'ReportResponse' (90% confidence)`
- `app\schemas.py:16: unused variable 'cls' (100% confidence)`
- `app\schemas.py:62: unused variable 'cls' (100% confidence)`
- `mcp_fastmcp_server.py:1040: unused variable 'dir' (100% confidence)`

**🤯 Complex Functions (Radon)**
| File | Function | Rank | Score |
|---|---|---|---|
| mcp_fastmcp_server.py | run_architecture_visualizer | D | 22 |
| mcp_fastmcp_server.py | generate_full_markdown_report | C | 20 |
| mcp_fastmcp_server.py | run_auto_fix | C | 19 |
| mcp_fastmcp_server.py | run_tests_coverage | C | 15 |
| mcp_fastmcp_server.py | run_cleanup_scan | C | 14 |
| mcp_fastmcp_server.py | run_pip_audit | C | 13 |
| mcp_fastmcp_server.py | run_efficiency | C | 12 |
| mcp_fastmcp_server.py | run_secrets | C | 11 |
| mcp_fastmcp_server.py | run_dead_code | C | 11 |
| self_audit.py | run_self_audit | C | 16 |
| validate_dataset.py | validate_dataset | D | 23 |
| analyzer_agent.py | _calculate_score | D | 21 |
| analyzer_agent.py | analyze_project | C | 18 |
| report_generator.py | _write_top_issues_summary | C | 18 |
| report_generator.py | _write_enterprise_tests | C | 16 |
| report_generator.py | _write_top_action_roadmap | C | 13 |
| report_generator.py | _write_self_healing_section | C | 11 |
| report_generator.py | _write_mandatory_deadcode | C | 11 |
| report_sections.py | _write_security_section | C | 17 |
| architecture_tool.py | _check_separation_of_concerns | C | 13 |

**🗑️ Junk / Cleanup**
- **Total Reclaimable:** 64.87 MB
  - `__pycache__`: 301 items
  - `.pytest_cache`: 1 items
  - `htmlcov`: 1 items
  - `*.pyc`: 2612 items

### 🧪 Tests & Coverage
- **Coverage:** 34%
- **Passed:** 26 ✅
- **Failed:** 2 ❌

---
*Generated by Python Auditor MCP v2.1*