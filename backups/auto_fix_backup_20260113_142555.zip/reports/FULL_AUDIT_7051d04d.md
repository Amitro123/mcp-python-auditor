# 🕵️‍♂️ Project Audit Report: mcp-python-auditor
**Score:** 74/100 🟡 | **Date:** 2026-01-13 13:02
**Scan Duration:** 66.68s | **Job ID:** `7051d04d`

## 🔧 Self-Healing Status
**Status:** Healthy ✅ (No missing tools detected)

## 🚨 Top Priorities
1. 🟡 **Testing:** Very low coverage (34%)

## 🗺️ Architecture
```mermaid
graph TD
    demo_autofix[demo_autofix] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> fastmcp[fastmcp]
    mcp_fastmcp_server[mcp_fastmcp_server] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> ast[ast]
    mcp_server[mcp_server] --> app[app]
    self_audit[self_audit] --> app[app]
    test_direct[test_direct] --> app[app]
    test_mcp_tools[test_mcp_tools] --> app[app]
    app_main[app/main] --> fastapi[fastapi]
    app_main[app/main] --> app[app]
    app_main[app/main] --> uvicorn[uvicorn]
    app_schemas[app/schemas] --> pydantic[pydantic]
    tests_conftest[tests/conftest] --> pytest[pytest]
    tests_conftest[tests/conftest] --> app[app]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> pytest[pytest]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> app[app]
    tests_test_api[tests/test_api] --> pytest[pytest]
    tests_test_api[tests/test_api] --> fastapi[fastapi]
    tests_test_api[tests/test_api] --> app[app]
    tests_test_parallel_audit[tests/test_parallel_audit] --> pytest[pytest]
    tests_test_parallel_audit[tests/test_parallel_audit] --> app[app]
    tests_test_tools[tests/test_tools] --> pytest[pytest]
    tests_test_tools[tests/test_tools] --> app[app]
    tests_test_tool_fixes[tests/test_tool_fixes] --> pytest[pytest]
    tests_test_tool_fixes[tests/test_tool_fixes] --> app[app]
    app_agents_analyzer_agent[app/agents/analyzer_agent] --> app[app]
    app_core_config[app/core/config] --> yaml[yaml]
    app_core_config[app/core/config] --> app[app]
    app_core_config[app/core/config] --> tomllib[tomllib]
    app_core_config[app/core/config] --> tomli[tomli]
    app_core_fix_orchestrator[app/core/fix_orchestrator] --> app[app]
    app_core_report_generator[app/core/report_generator] --> app[app]
    app_core_tool_registry[app/core/tool_registry] --> app[app]
    app_tools_architecture_tool[app/tools/architecture_tool] --> ast[ast]
    app_tools_architecture_tool[app/tools/architecture_tool] --> app[app]
    app_tools_cleanup_tool[app/tools/cleanup_tool] --> app[app]
    app_tools_complexity_tool[app/tools/complexity_tool] --> app[app]
    app_tools_deadcode_tool[app/tools/deadcode_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> ast[ast]
    app_tools_duplication_tool[app/tools/duplication_tool] --> rapidfuzz[rapidfuzz]
    app_tools_duplication_tool[app/tools/duplication_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> astor[astor]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> ast[ast]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> app[app]
    app_tools_gitignore_tool[app/tools/gitignore_tool] --> app[app]
    app_tools_git_tool[app/tools/git_tool] --> app[app]
    app_tools_secrets_tool[app/tools/secrets_tool] --> app[app]
    app_tools_security_tool[app/tools/security_tool] --> app[app]
    app_tools_structure_tool[app/tools/structure_tool] --> app[app]
    app_tools_tests_tool[app/tools/tests_tool] --> app[app]
```

[🔍 **Open Interactive Graph in Browser**](https://mermaid.live/edit#base64:Z3JhcGggVEQKICAgIGRlbW9fYXV0b2ZpeFtkZW1vX2F1dG9maXhdIC0tPiBhcHBbYXBwXQogICAgbWNwX2Zhc3RtY3Bfc2VydmVyW21jcF9mYXN0bWNwX3NlcnZlcl0gLS0+IGZhc3RtY3BbZmFzdG1jcF0KICAgIG1jcF9mYXN0bWNwX3NlcnZlclttY3BfZmFzdG1jcF9zZXJ2ZXJdIC0tPiBhcHBbYXBwXQogICAgbWNwX2Zhc3RtY3Bfc2VydmVyW21jcF9mYXN0bWNwX3NlcnZlcl0gLS0+IGFzdFthc3RdCiAgICBtY3Bfc2VydmVyW21jcF9zZXJ2ZXJdIC0tPiBhcHBbYXBwXQogICAgc2VsZl9hdWRpdFtzZWxmX2F1ZGl0XSAtLT4gYXBwW2FwcF0KICAgIHRlc3RfZGlyZWN0W3Rlc3RfZGlyZWN0XSAtLT4gYXBwW2FwcF0KICAgIHRlc3RfbWNwX3Rvb2xzW3Rlc3RfbWNwX3Rvb2xzXSAtLT4gYXBwW2FwcF0KICAgIGFwcF9tYWluW2FwcC9tYWluXSAtLT4gZmFzdGFwaVtmYXN0YXBpXQogICAgYXBwX21haW5bYXBwL21haW5dIC0tPiBhcHBbYXBwXQogICAgYXBwX21haW5bYXBwL21haW5dIC0tPiB1dmljb3JuW3V2aWNvcm5dCiAgICBhcHBfc2NoZW1hc1thcHAvc2NoZW1hc10gLS0+IHB5ZGFudGljW3B5ZGFudGljXQogICAgdGVzdHNfY29uZnRlc3RbdGVzdHMvY29uZnRlc3RdIC0tPiBweXRlc3RbcHl0ZXN0XQogICAgdGVzdHNfY29uZnRlc3RbdGVzdHMvY29uZnRlc3RdIC0tPiBhcHBbYXBwXQogICAgdGVzdHNfdGVzdF9hbmFseXplcl9hZ2VudFt0ZXN0cy90ZXN0X2FuYWx5emVyX2FnZW50XSAtLT4gcHl0ZXN0W3B5dGVzdF0KICAgIHRlc3RzX3Rlc3RfYW5hbHl6ZXJfYWdlbnRbdGVzdHMvdGVzdF9hbmFseXplcl9hZ2VudF0gLS0+IGFwcFthcHBdCiAgICB0ZXN0c190ZXN0X2FwaVt0ZXN0cy90ZXN0X2FwaV0gLS0+IHB5dGVzdFtweXRlc3RdCiAgICB0ZXN0c190ZXN0X2FwaVt0ZXN0cy90ZXN0X2FwaV0gLS0+IGZhc3RhcGlbZmFzdGFwaV0KICAgIHRlc3RzX3Rlc3RfYXBpW3Rlc3RzL3Rlc3RfYXBpXSAtLT4gYXBwW2FwcF0KICAgIHRlc3RzX3Rlc3RfcGFyYWxsZWxfYXVkaXRbdGVzdHMvdGVzdF9wYXJhbGxlbF9hdWRpdF0gLS0+IHB5dGVzdFtweXRlc3RdCiAgICB0ZXN0c190ZXN0X3BhcmFsbGVsX2F1ZGl0W3Rlc3RzL3Rlc3RfcGFyYWxsZWxfYXVkaXRdIC0tPiBhcHBbYXBwXQogICAgdGVzdHNfdGVzdF90b29sc1t0ZXN0cy90ZXN0X3Rvb2xzXSAtLT4gcHl0ZXN0W3B5dGVzdF0KICAgIHRlc3RzX3Rlc3RfdG9vbHNbdGVzdHMvdGVzdF90b29sc10gLS0+IGFwcFthcHBdCiAgICB0ZXN0c190ZXN0X3Rvb2xfZml4ZXNbdGVzdHMvdGVzdF90b29sX2ZpeGVzXSAtLT4gcHl0ZXN0W3B5dGVzdF0KICAgIHRlc3RzX3Rlc3RfdG9vbF9maXhlc1t0ZXN0cy90ZXN0X3Rvb2xfZml4ZXNdIC0tPiBhcHBbYXBwXQogICAgYXBwX2FnZW50c19hbmFseXplcl9hZ2VudFthcHAvYWdlbnRzL2FuYWx5emVyX2FnZW50XSAtLT4gYXBwW2FwcF0KICAgIGFwcF9jb3JlX2NvbmZpZ1thcHAvY29yZS9jb25maWddIC0tPiB5YW1sW3lhbWxdCiAgICBhcHBfY29yZV9jb25maWdbYXBwL2NvcmUvY29uZmlnXSAtLT4gYXBwW2FwcF0KICAgIGFwcF9jb3JlX2NvbmZpZ1thcHAvY29yZS9jb25maWddIC0tPiB0b21sbGliW3RvbWxsaWJdCiAgICBhcHBfY29yZV9jb25maWdbYXBwL2NvcmUvY29uZmlnXSAtLT4gdG9tbGlbdG9tbGldCiAgICBhcHBfY29yZV9maXhfb3JjaGVzdHJhdG9yW2FwcC9jb3JlL2ZpeF9vcmNoZXN0cmF0b3JdIC0tPiBhcHBbYXBwXQogICAgYXBwX2NvcmVfcmVwb3J0X2dlbmVyYXRvclthcHAvY29yZS9yZXBvcnRfZ2VuZXJhdG9yXSAtLT4gYXBwW2FwcF0KICAgIGFwcF9jb3JlX3Rvb2xfcmVnaXN0cnlbYXBwL2NvcmUvdG9vbF9yZWdpc3RyeV0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfYXJjaGl0ZWN0dXJlX3Rvb2xbYXBwL3Rvb2xzL2FyY2hpdGVjdHVyZV90b29sXSAtLT4gYXN0W2FzdF0KICAgIGFwcF90b29sc19hcmNoaXRlY3R1cmVfdG9vbFthcHAvdG9vbHMvYXJjaGl0ZWN0dXJlX3Rvb2xdIC0tPiBhcHBbYXBwXQogICAgYXBwX3Rvb2xzX2NsZWFudXBfdG9vbFthcHAvdG9vbHMvY2xlYW51cF90b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19jb21wbGV4aXR5X3Rvb2xbYXBwL3Rvb2xzL2NvbXBsZXhpdHlfdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZGVhZGNvZGVfdG9vbFthcHAvdG9vbHMvZGVhZGNvZGVfdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IGFzdFthc3RdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IHJhcGlkZnV6eltyYXBpZGZ1enpdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IGFzdG9yW2FzdG9yXQogICAgYXBwX3Rvb2xzX2VmZmljaWVuY3lfdG9vbFthcHAvdG9vbHMvZWZmaWNpZW5jeV90b29sXSAtLT4gYXN0W2FzdF0KICAgIGFwcF90b29sc19lZmZpY2llbmN5X3Rvb2xbYXBwL3Rvb2xzL2VmZmljaWVuY3lfdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZ2l0aWdub3JlX3Rvb2xbYXBwL3Rvb2xzL2dpdGlnbm9yZV90b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19naXRfdG9vbFthcHAvdG9vbHMvZ2l0X3Rvb2xdIC0tPiBhcHBbYXBwXQogICAgYXBwX3Rvb2xzX3NlY3JldHNfdG9vbFthcHAvdG9vbHMvc2VjcmV0c190b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19zZWN1cml0eV90b29sW2FwcC90b29scy9zZWN1cml0eV90b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19zdHJ1Y3R1cmVfdG9vbFthcHAvdG9vbHMvc3RydWN0dXJlX3Rvb2xdIC0tPiBhcHBbYXBwXQogICAgYXBwX3Rvb2xzX3Rlc3RzX3Rvb2xbYXBwL3Rvb2xzL3Rlc3RzX3Rvb2xdIC0tPiBhcHBbYXBwXQ==)

**Stats:** 45 files, 50 dependencies

## 📊 Detailed Findings
### 🛡️ Security (0 issues)
✅ No security issues found.

### 🧪 Tests & Coverage
- **Coverage:** 34%
- **Passed:** 26 ✅
- **Failed:** 2 ❌

### 🧹 Code Quality & Hygiene
- **Linting (Ruff):** 0 issues
- **Dead Code (Vulture):** 6 items
- **Complexity (Radon):** 31 complex blocks
- **Junk Files:** 64.81 MB reclaimable

---
*Generated by Python Auditor MCP v2.0*