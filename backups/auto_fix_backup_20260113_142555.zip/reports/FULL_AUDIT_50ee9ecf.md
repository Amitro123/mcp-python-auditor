# 🕵️‍♂️ Project Audit Report: mcp-python-auditor
**Score:** 90/100 🟢 | **Date:** 2026-01-13 14:19
**Scan Duration:** 78.98s | **Job ID:** `50ee9ecf`

## 🔧 Self-Healing Status
**Status:** Healthy ✅ (No missing tools detected)

## 🚨 Top Priorities
1. 🟡 **Testing:** Very low coverage (33%)

## 📂 Project Structure
**Files:** 2540 Python | **Lines:** 0
### 📁 Tree View
```
├── 📁 app
│   ├── 📁 agents
│   │   ├── 🐍 __init__.py
│   │   └── 🐍 analyzer_agent.py
│   ├── 📁 core
│   │   ├── 🐍 __init__.py
│   │   ├── 🐍 base_tool.py
│   │   ├── 🐍 config.py
│   │   ├── 🐍 fix_orchestrator.py
│   │   ├── 🐍 report_generator.py
│   │   ├── 📄 report_generator.py.bak
│   │   ├── 🐍 report_sections.py
│   │   ├── 🐍 self_healing.py
│   │   ├── 🐍 subprocess_wrapper.py
│   │   └── 🐍 tool_registry.py
│   ├── 📁 tools
│   │   ├── 🐍 __init__.py
│   │   ├── 🐍 architecture_tool.py
│   │   ├── 🐍 cleanup_tool.py
│   │   ├── 📄 cleanup_tool.py.bak
│   │   ├── 🐍 code_editor_tool.py
│   │   ├── 🐍 complexity_tool.py
│   │   ├── 🐍 deadcode_tool.py
│   │   ├── 🐍 duplication_tool.py
│   │   ├── 🐍 efficiency_tool.py
│   │   ├── 🐍 git_tool.py
│   │   ├── 🐍 gitignore_tool.py
│   │   ├── 🐍 secrets_tool.py
│   │   ├── 🐍 security_tool.py
│   │   ├── 🐍 structure_tool.py
│   │   ├── 🐍 tests_tool.py
│   │   └── 🐍 typing_tool.py
│   ├── 🐍 __init__.py
│   ├── 🐍 main.py
│   ├── 📄 main.py.bak
│   └── 🐍 schemas.py
├── 📁 data
│   ├── 📄 README_DATASET.md
│   ├── 📄 audit_dataset.jsonl
│   ├── 📄 audit_dataset_500.jsonl
│   └── 📄 audit_dataset_fixed.jsonl
├── 📁 finetune
│   ├── 🐍 fix_notebook.py
│   └── 📄 kaggle_finetune.ipynb
├── 📁 fresh-install-test
├── 📁 tests
│   ├── 🐍 __init__.py
│   ├── 🐍 conftest.py
│   ├── 🐍 test_analyzer_agent.py
│   ├── 🐍 test_api.py
│   ├── 🐍 test_parallel_audit.py
│   ├── 🐍 test_tool_fixes.py
│   └── 🐍 test_tools.py
├── 📄 AMIT_CODING_PREFERENCES.md
├── 📄 AUTOFIX_GUIDE.md
├── 📄 AUTOFIX_QUICK_REF.md
├── 📄 BEFORE_AFTER_COMPARISON.md
├── 📄 CENTRALIZED_EXCLUSIONS_COMPLETE.md
├── 📄 CHANGES_TRACKER.md
├── 📄 Dockerfile
├── 📄 FULL_VISIBILITY_REFACTOR.md
├── 📄 IMPLEMENTATION_SUMMARY.md
├── 📄 INTEGRATION_GUIDE.md
├── 📄 MCP_INTEGRATION.md
├── 📄 PRODUCTION_REFINEMENTS.md
├── 📄 QUICK_MCP_SETUP.md
├── 📄 QUICK_REFERENCE_GUIDE.md
├── 📄 README.md
├── 📄 SELF_AUDIT_REPORT.md
├── 📄 SESSION_SUMMARY.md
├── 📄 SMART_ROOT_DETECTION.md
├── 📄 SMART_ROOT_VISUAL_COMPARISON.md
├── 📄 audit.yaml.example
├── 🐍 dataset_templates.py
├── 📄 debug_audit.txt
├── 🐍 demo_autofix.py
├── 📄 docker-compose.yml
├── 🐍 duplication_helper.py
├── 🐍 mcp_fastmcp_server.py
├── 🐍 mcp_server.py
├── 📄 pyproject.toml
├── 📄 requirements.txt
├── 🐍 self_audit.py
├── 📄 self_audit.py.bak
├── 🐍 test_direct.py
├── 🐍 test_mcp_tools.py
└── 🐍 validate_dataset.py
```

## 🗺️ Architecture Logic
```mermaid
graph TD
    subgraph App
        app___init__[app/__init__]
        app_agents___init__[app/agents/__init__]
        app_agents_analyzer_agent[app/agents/analyzer_agent]
        app_core___init__[app/core/__init__]
        app_core_base_tool[app/core/base_tool]
        app_core_config[app/core/config]
        app_core_fix_orchestrator[app/core/fix_orchestrator]
        app_core_report_generator[app/core/report_generator]
        app_core_report_sections[app/core/report_sections]
        app_core_self_healing[app/core/self_healing]
        app_core_subprocess_wrapper[app/core/subprocess_wrapper]
        app_core_tool_registry[app/core/tool_registry]
        app_main[app/main]
        app_schemas[app/schemas]
        app_tools___init__[app/tools/__init__]
        app_tools_architecture_tool[app/tools/architecture_tool]
        app_tools_cleanup_tool[app/tools/cleanup_tool]
        app_tools_code_editor_tool[app/tools/code_editor_tool]
        app_tools_complexity_tool[app/tools/complexity_tool]
        app_tools_deadcode_tool[app/tools/deadcode_tool]
        app_tools_duplication_tool[app/tools/duplication_tool]
        app_tools_efficiency_tool[app/tools/efficiency_tool]
        app_tools_git_tool[app/tools/git_tool]
        app_tools_gitignore_tool[app/tools/gitignore_tool]
        app_tools_secrets_tool[app/tools/secrets_tool]
        app_tools_security_tool[app/tools/security_tool]
        app_tools_structure_tool[app/tools/structure_tool]
        app_tools_tests_tool[app/tools/tests_tool]
        app_tools_typing_tool[app/tools/typing_tool]
    end
    subgraph Root
        dataset_templates[dataset_templates]
        demo_autofix[demo_autofix]
        duplication_helper[duplication_helper]
        mcp_fastmcp_server[mcp_fastmcp_server]
        mcp_server[mcp_server]
        self_audit[self_audit]
        test_direct[test_direct]
        test_mcp_tools[test_mcp_tools]
        validate_dataset[validate_dataset]
    end
    subgraph Tests
        tests___init__[tests/__init__]
        tests_conftest[tests/conftest]
        tests_test_analyzer_agent[tests/test_analyzer_agent]
        tests_test_api[tests/test_api]
        tests_test_parallel_audit[tests/test_parallel_audit]
        tests_test_tool_fixes[tests/test_tool_fixes]
        tests_test_tools[tests/test_tools]
    end
    demo_autofix --> app
    mcp_fastmcp_server --> fastmcp
    mcp_fastmcp_server --> app
    mcp_fastmcp_server --> ast
    mcp_server --> app
    self_audit --> app
    test_direct --> app
    test_mcp_tools --> app
    app_main --> fastapi
    app_main --> app
    app_main --> uvicorn
    app_schemas --> pydantic
    tests_conftest --> pytest
    tests_conftest --> app
    tests_test_analyzer_agent --> pytest
    tests_test_analyzer_agent --> app
    tests_test_api --> pytest
    tests_test_api --> fastapi
    tests_test_api --> app
    tests_test_parallel_audit --> pytest
    tests_test_parallel_audit --> app
    tests_test_tools --> pytest
    tests_test_tools --> app
    tests_test_tool_fixes --> pytest
    tests_test_tool_fixes --> app
    app_agents_analyzer_agent --> app
    app_core_config --> yaml
    app_core_config --> app
    app_core_config --> tomllib
    app_core_config --> tomli
    app_core_fix_orchestrator --> app
    app_core_report_generator --> app
    app_core_tool_registry --> app
    app_tools_architecture_tool --> ast
    app_tools_architecture_tool --> app
    app_tools_cleanup_tool --> app
    app_tools_complexity_tool --> app
    app_tools_deadcode_tool --> app
    app_tools_duplication_tool --> ast
    app_tools_duplication_tool --> rapidfuzz
    app_tools_duplication_tool --> app
    app_tools_duplication_tool --> astor
    app_tools_efficiency_tool --> ast
    app_tools_efficiency_tool --> app
    app_tools_gitignore_tool --> app
    app_tools_git_tool --> app
    app_tools_secrets_tool --> app
    app_tools_security_tool --> app
    app_tools_structure_tool --> app
    app_tools_tests_tool --> app
```
[🔍 **Open Interactive Graph**](https://mermaid.live/edit#pako:eNqNWE1v3CAQ_Ssrnxv13kOlSv0FVW5uhVh7vIuEAQFOs4ny3zvY3vA1eJtLYN57A2aGYZL3btAjdN9O3cVycz09__ytTvjjlvNm-GHMZgk_3BjGmFDCM9bj5Ot98ifn8Aso73LqZnug4IrL2xvYbZ7qcqRQD9pCvlqwtNZa2WfugHmtZaR_mij-oNUkLpG8zSnmJF6ZtsMVnLfcaxs1JUKpLRhtPcOPhEJdIgdqB4MXWrlKfAcorQM5sStwKVTynamVVC1nY_UAzrG_mDAGkh3XGOUhnDhu_CLwVG5RnJkL3cyFWplhUGAOz3fm26fv44IRPBfJuZpa-bLxOQZOeDy_xSaJswkrjPQwSOBqMaU4NdM6vKEMRoExr7QF1NDPRsKr8LdaniGkegQ-rssU2sxOKxcjxcBDwlXiAiL1ME1iEKCGat8FQqovGMlCdje1-OKidB3cHCC1eK0sYPkqlKm5pVssEZfMTiu9XchUzAFS67H-VHuNRlpzM1gAKlG07ipQY_GA_NLaR48j91hlMQyAmcdx0b6yJOuPMGvGF6-xcvbpJOUkqXQFGQpQbUr482DYxJ0Pvx3YF-TXpoKf8Cp8LZB8wTvYx2GCh4Nlo7BYHfpkXDKC7_VQ-3ya8F6wCONpAduPrC8NzRg8h-DmCyYFcJ1SxW_jhZcujHbefVrx1n0XD_gmIZCG2ohMYgTNM9xyKUHu555IcoRWry8LJhG4VBmtbVUlcOWRp0l6enr6Hq7QhtRJtuK76ZDzyAdaIk7pYmLm9iQfCeAzB3Ps_gB_bh_DRCA0f3kR-LqriOxP9Aqa28iVF0PcQ8y-nRCGTTjbPpmQDS8tJunQiEMvO5wdDIFTrvPkPVqFYFIOY_QafojwkhflkY-ElcWdbOtrWtJhr-CNz7KNHkq9nqUU52OCKOCyMW8sU3bgDVrWudacRjuZ3-SHxNpj2kc2OXnD16JlvV2TVPRwrQ8gefgsiXFa3t7-z-v_r65tySyaxdY2SVq9bt4NHrAO8bQzPODEJrBJytq9Fis2d3dG9-XUzWCxLo_4x_9757EKr_8GGGHii_Tdx8c_W9u3hg==)

## 📊 Detailed Findings
### 🛡️ Security (0 issues)
✅ No security issues found.

### 🧹 Code Quality & Hygiene
**💀 Dead Code / Unused (5 items)**
- `app\core\report_generator.py:12: unused import '_write_security_section' (90% confidence)`
- `app\main.py:12: unused import 'ReportResponse' (90% confidence)`
- `app\schemas.py:16: unused variable 'cls' (100% confidence)`
- `app\schemas.py:62: unused variable 'cls' (100% confidence)`
- `mcp_fastmcp_server.py:1214: unused variable 'dir' (100% confidence)`

**🤯 Complex Functions (Radon)**
| File | Function | Rank | Score |
|---|---|---|---|
| duplication_helper.py | run_duplication | C | 16 |
| mcp_fastmcp_server.py | generate_full_markdown_report | D | 27 |
| mcp_fastmcp_server.py | run_architecture_visualizer | D | 26 |
| mcp_fastmcp_server.py | run_auto_fix | C | 19 |
| mcp_fastmcp_server.py | run_duplication | C | 16 |
| mcp_fastmcp_server.py | run_tests_coverage | C | 15 |
| mcp_fastmcp_server.py | run_cleanup_scan | C | 14 |
| mcp_fastmcp_server.py | run_pip_audit | C | 13 |
| mcp_fastmcp_server.py | run_efficiency | C | 12 |
| mcp_fastmcp_server.py | run_secrets | C | 11 |
| mcp_fastmcp_server.py | run_dead_code | C | 11 |
| self_audit.py | run_self_audit | C | 16 |
| validate_dataset.py | validate_dataset | D | 23 |
| analyzer_agent.py | _calculate_score | D | 21 |
| analyzer_agent.py | analyze_project | C | 18 |
| report_generator.py | _write_top_issues_summary | C | 18 |
| report_generator.py | _write_enterprise_tests | C | 16 |
| report_generator.py | _write_top_action_roadmap | C | 13 |
| report_generator.py | _write_self_healing_section | C | 11 |
| report_generator.py | _write_mandatory_deadcode | C | 11 |

## 🎭 DUPLICATES (Grouped + Actionable)
**Found 6383 duplicated blocks.**
- **Hash:** `81e85647` (51 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:75`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:195`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:830`
  - ...and 2 more
- **Hash:** `4a572b0a` (39 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:66`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:185`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:263`
  - ...and 2 more
- **Hash:** `6f95a3f5` (39 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:67`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:186`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:264`
  - ...and 2 more
- **Hash:** `881acf70` (38 copies)
  - `.venv\Lib\site-packages\fastapi\applications.py:734`
  - `.venv\Lib\site-packages\fastapi\applications.py:1267`
  - `.venv\Lib\site-packages\fastapi\applications.py:1551`
  - ...and 2 more
- **Hash:** `7b60e182` (35 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:76`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:196`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:831`
  - ...and 2 more

**🗑️ Junk / Cleanup**
- **Total Reclaimable:** 65.01 MB
  - `__pycache__`: 301 items
  - `.pytest_cache`: 1 items
  - `htmlcov`: 1 items
  - `*.pyc`: 2612 items

### 🧪 Tests & Coverage
- **Coverage:** 33%
- **Passed:** 26 ✅
- **Failed:** 2 ❌

---
*Generated by Python Auditor MCP v2.1*