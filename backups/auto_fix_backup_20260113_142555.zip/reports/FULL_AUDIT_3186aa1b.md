# 🕵️‍♂️ Project Audit Report: mcp-python-auditor
**Score:** 90/100 🟢 | **Date:** 2026-01-13 13:37
**Scan Duration:** 74.37s | **Job ID:** `3186aa1b`

## 🔧 Self-Healing Status
**Status:** Healthy ✅ (No missing tools detected)

## 🚨 Top Priorities
1. 🟡 **Testing:** Very low coverage (33%)

## 📂 Project Structure
**Files:** 2540 Python | **Lines:** 0
### 📁 Tree View
```
├── 📁 app
│   ├── 📁 agents
│   │   ├── 🐍 __init__.py
│   │   └── 🐍 analyzer_agent.py
│   ├── 📁 core
│   │   ├── 🐍 __init__.py
│   │   ├── 🐍 base_tool.py
│   │   ├── 🐍 config.py
│   │   ├── 🐍 fix_orchestrator.py
│   │   ├── 🐍 report_generator.py
│   │   ├── 📄 report_generator.py.bak
│   │   ├── 🐍 report_sections.py
│   │   ├── 🐍 self_healing.py
│   │   ├── 🐍 subprocess_wrapper.py
│   │   └── 🐍 tool_registry.py
│   ├── 📁 tools
│   │   ├── 🐍 __init__.py
│   │   ├── 🐍 architecture_tool.py
│   │   ├── 🐍 cleanup_tool.py
│   │   ├── 📄 cleanup_tool.py.bak
│   │   ├── 🐍 code_editor_tool.py
│   │   ├── 🐍 complexity_tool.py
│   │   ├── 🐍 deadcode_tool.py
│   │   ├── 🐍 duplication_tool.py
│   │   ├── 🐍 efficiency_tool.py
│   │   ├── 🐍 git_tool.py
│   │   ├── 🐍 gitignore_tool.py
│   │   ├── 🐍 secrets_tool.py
│   │   ├── 🐍 security_tool.py
│   │   ├── 🐍 structure_tool.py
│   │   ├── 🐍 tests_tool.py
│   │   └── 🐍 typing_tool.py
│   ├── 🐍 __init__.py
│   ├── 🐍 main.py
│   ├── 📄 main.py.bak
│   └── 🐍 schemas.py
├── 📁 data
│   ├── 📄 README_DATASET.md
│   ├── 📄 audit_dataset.jsonl
│   ├── 📄 audit_dataset_500.jsonl
│   └── 📄 audit_dataset_fixed.jsonl
├── 📁 finetune
│   ├── 🐍 fix_notebook.py
│   └── 📄 kaggle_finetune.ipynb
├── 📁 fresh-install-test
├── 📁 htmlcov
│   ├── 📄 class_index.html
│   ├── 📄 coverage_html_cb_497bf287.js
│   ├── 📄 dataset_templates_py.html
│   ├── 📄 demo_autofix_py.html
│   ├── 📄 favicon_32_cb_58284776.png
│   ├── 📄 function_index.html
│   ├── 📄 generate_dataset_500_py.html
│   ├── 📄 generate_full_dataset_py.html
│   ├── 📄 index.html
│   ├── 📄 keybd_closed_cb_ce680311.png
│   ├── 📄 mcp_fastmcp_server_py.html
│   ├── 📄 mcp_server_py.html
│   ├── 📄 self_audit_py.html
│   ├── 📄 status.json
│   ├── 📄 style_cb_718ce007.css
│   ├── 📄 test_direct_py.html
│   ├── 📄 test_mcp_tools_py.html
│   ├── 📄 validate_dataset_py.html
│   ├── 📄 z_03a2b55df94201d0_main_py.html
│   ├── 📄 z_03a2b55df94201d0_utils_py.html
│   ├── 📄 z_0bd8aef1c615c404_main_py.html
│   ├── 📄 z_0bd8aef1c615c404_utils_py.html
│   ├── 📄 z_1500a5273080a382_main_py.html
│   ├── 📄 z_1500a5273080a382_utils_py.html
│   ├── 📄 z_1887c19adfc8c03c_main_py.html
│   ├── 📄 z_1887c19adfc8c03c_utils_py.html
│   ├── 📄 z_2ef29ffa67ca5739_main_py.html
│   ├── 📄 z_2ef29ffa67ca5739_utils_py.html
│   ├── 📄 z_3698c4690eb2c8ec_main_py.html
│   ├── 📄 z_3698c4690eb2c8ec_utils_py.html
│   ├── 📄 z_39795c679c66d98b___init___py.html
│   ├── 📄 z_39795c679c66d98b_architecture_tool_py.html
│   ├── 📄 z_39795c679c66d98b_cleanup_tool_py.html
│   ├── 📄 z_39795c679c66d98b_code_editor_tool_py.html
│   ├── 📄 z_39795c679c66d98b_complexity_tool_py.html
│   ├── 📄 z_39795c679c66d98b_deadcode_tool_py.html
│   ├── 📄 z_39795c679c66d98b_duplication_tool_py.html
│   ├── 📄 z_39795c679c66d98b_efficiency_tool_py.html
│   ├── 📄 z_39795c679c66d98b_git_tool_py.html
│   ├── 📄 z_39795c679c66d98b_gitignore_tool_py.html
│   ├── 📄 z_39795c679c66d98b_secrets_tool_py.html
│   ├── 📄 z_39795c679c66d98b_security_tool_py.html
│   ├── 📄 z_39795c679c66d98b_structure_tool_py.html
│   ├── 📄 z_39795c679c66d98b_tests_tool_py.html
│   ├── 📄 z_39795c679c66d98b_typing_tool_py.html
│   ├── 📄 z_5f5a17c013354698___init___py.html
│   ├── 📄 z_5f5a17c013354698_main_py.html
│   ├── 📄 z_5f5a17c013354698_schemas_py.html
│   ├── 📄 z_7979132b6380b48d_main_py.html
│   ├── 📄 z_7979132b6380b48d_utils_py.html
│   ├── 📄 z_7e7d0e83ff2f91d5_main_py.html
│   ├── 📄 z_7e7d0e83ff2f91d5_utils_py.html
│   ├── 📄 z_86161c9626f0837e_main_py.html
│   ├── 📄 z_86161c9626f0837e_utils_py.html
... (truncated for brevity)
```

## 🗺️ Architecture Logic
```mermaid
graph TD
    demo_autofix[demo_autofix] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> fastmcp[fastmcp]
    mcp_fastmcp_server[mcp_fastmcp_server] --> app[app]
    mcp_fastmcp_server[mcp_fastmcp_server] --> ast[ast]
    mcp_server[mcp_server] --> app[app]
    self_audit[self_audit] --> app[app]
    test_direct[test_direct] --> app[app]
    test_mcp_tools[test_mcp_tools] --> app[app]
    app_main[app/main] --> fastapi[fastapi]
    app_main[app/main] --> app[app]
    app_main[app/main] --> uvicorn[uvicorn]
    app_schemas[app/schemas] --> pydantic[pydantic]
    tests_conftest[tests/conftest] --> pytest[pytest]
    tests_conftest[tests/conftest] --> app[app]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> pytest[pytest]
    tests_test_analyzer_agent[tests/test_analyzer_agent] --> app[app]
    tests_test_api[tests/test_api] --> pytest[pytest]
    tests_test_api[tests/test_api] --> fastapi[fastapi]
    tests_test_api[tests/test_api] --> app[app]
    tests_test_parallel_audit[tests/test_parallel_audit] --> pytest[pytest]
    tests_test_parallel_audit[tests/test_parallel_audit] --> app[app]
    tests_test_tools[tests/test_tools] --> pytest[pytest]
    tests_test_tools[tests/test_tools] --> app[app]
    tests_test_tool_fixes[tests/test_tool_fixes] --> pytest[pytest]
    tests_test_tool_fixes[tests/test_tool_fixes] --> app[app]
    app_agents_analyzer_agent[app/agents/analyzer_agent] --> app[app]
    app_core_config[app/core/config] --> yaml[yaml]
    app_core_config[app/core/config] --> app[app]
    app_core_config[app/core/config] --> tomllib[tomllib]
    app_core_config[app/core/config] --> tomli[tomli]
    app_core_fix_orchestrator[app/core/fix_orchestrator] --> app[app]
    app_core_report_generator[app/core/report_generator] --> app[app]
    app_core_tool_registry[app/core/tool_registry] --> app[app]
    app_tools_architecture_tool[app/tools/architecture_tool] --> ast[ast]
    app_tools_architecture_tool[app/tools/architecture_tool] --> app[app]
    app_tools_cleanup_tool[app/tools/cleanup_tool] --> app[app]
    app_tools_complexity_tool[app/tools/complexity_tool] --> app[app]
    app_tools_deadcode_tool[app/tools/deadcode_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> ast[ast]
    app_tools_duplication_tool[app/tools/duplication_tool] --> rapidfuzz[rapidfuzz]
    app_tools_duplication_tool[app/tools/duplication_tool] --> app[app]
    app_tools_duplication_tool[app/tools/duplication_tool] --> astor[astor]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> ast[ast]
    app_tools_efficiency_tool[app/tools/efficiency_tool] --> app[app]
    app_tools_gitignore_tool[app/tools/gitignore_tool] --> app[app]
    app_tools_git_tool[app/tools/git_tool] --> app[app]
    app_tools_secrets_tool[app/tools/secrets_tool] --> app[app]
    app_tools_security_tool[app/tools/security_tool] --> app[app]
    app_tools_structure_tool[app/tools/structure_tool] --> app[app]
    app_tools_tests_tool[app/tools/tests_tool] --> app[app]
```
[🔍 **Open Interactive Graph**](https://mermaid.live/edit#base64:Z3JhcGggVEQKICAgIGRlbW9fYXV0b2ZpeFtkZW1vX2F1dG9maXhdIC0tPiBhcHBbYXBwXQogICAgbWNwX2Zhc3RtY3Bfc2VydmVyW21jcF9mYXN0bWNwX3NlcnZlcl0gLS0+IGZhc3RtY3BbZmFzdG1jcF0KICAgIG1jcF9mYXN0bWNwX3NlcnZlclttY3BfZmFzdG1jcF9zZXJ2ZXJdIC0tPiBhcHBbYXBwXQogICAgbWNwX2Zhc3RtY3Bfc2VydmVyW21jcF9mYXN0bWNwX3NlcnZlcl0gLS0+IGFzdFthc3RdCiAgICBtY3Bfc2VydmVyW21jcF9zZXJ2ZXJdIC0tPiBhcHBbYXBwXQogICAgc2VsZl9hdWRpdFtzZWxmX2F1ZGl0XSAtLT4gYXBwW2FwcF0KICAgIHRlc3RfZGlyZWN0W3Rlc3RfZGlyZWN0XSAtLT4gYXBwW2FwcF0KICAgIHRlc3RfbWNwX3Rvb2xzW3Rlc3RfbWNwX3Rvb2xzXSAtLT4gYXBwW2FwcF0KICAgIGFwcF9tYWluW2FwcC9tYWluXSAtLT4gZmFzdGFwaVtmYXN0YXBpXQogICAgYXBwX21haW5bYXBwL21haW5dIC0tPiBhcHBbYXBwXQogICAgYXBwX21haW5bYXBwL21haW5dIC0tPiB1dmljb3JuW3V2aWNvcm5dCiAgICBhcHBfc2NoZW1hc1thcHAvc2NoZW1hc10gLS0+IHB5ZGFudGljW3B5ZGFudGljXQogICAgdGVzdHNfY29uZnRlc3RbdGVzdHMvY29uZnRlc3RdIC0tPiBweXRlc3RbcHl0ZXN0XQogICAgdGVzdHNfY29uZnRlc3RbdGVzdHMvY29uZnRlc3RdIC0tPiBhcHBbYXBwXQogICAgdGVzdHNfdGVzdF9hbmFseXplcl9hZ2VudFt0ZXN0cy90ZXN0X2FuYWx5emVyX2FnZW50XSAtLT4gcHl0ZXN0W3B5dGVzdF0KICAgIHRlc3RzX3Rlc3RfYW5hbHl6ZXJfYWdlbnRbdGVzdHMvdGVzdF9hbmFseXplcl9hZ2VudF0gLS0+IGFwcFthcHBdCiAgICB0ZXN0c190ZXN0X2FwaVt0ZXN0cy90ZXN0X2FwaV0gLS0+IHB5dGVzdFtweXRlc3RdCiAgICB0ZXN0c190ZXN0X2FwaVt0ZXN0cy90ZXN0X2FwaV0gLS0+IGZhc3RhcGlbZmFzdGFwaV0KICAgIHRlc3RzX3Rlc3RfYXBpW3Rlc3RzL3Rlc3RfYXBpXSAtLT4gYXBwW2FwcF0KICAgIHRlc3RzX3Rlc3RfcGFyYWxsZWxfYXVkaXRbdGVzdHMvdGVzdF9wYXJhbGxlbF9hdWRpdF0gLS0+IHB5dGVzdFtweXRlc3RdCiAgICB0ZXN0c190ZXN0X3BhcmFsbGVsX2F1ZGl0W3Rlc3RzL3Rlc3RfcGFyYWxsZWxfYXVkaXRdIC0tPiBhcHBbYXBwXQogICAgdGVzdHNfdGVzdF90b29sc1t0ZXN0cy90ZXN0X3Rvb2xzXSAtLT4gcHl0ZXN0W3B5dGVzdF0KICAgIHRlc3RzX3Rlc3RfdG9vbHNbdGVzdHMvdGVzdF90b29sc10gLS0+IGFwcFthcHBdCiAgICB0ZXN0c190ZXN0X3Rvb2xfZml4ZXNbdGVzdHMvdGVzdF90b29sX2ZpeGVzXSAtLT4gcHl0ZXN0W3B5dGVzdF0KICAgIHRlc3RzX3Rlc3RfdG9vbF9maXhlc1t0ZXN0cy90ZXN0X3Rvb2xfZml4ZXNdIC0tPiBhcHBbYXBwXQogICAgYXBwX2FnZW50c19hbmFseXplcl9hZ2VudFthcHAvYWdlbnRzL2FuYWx5emVyX2FnZW50XSAtLT4gYXBwW2FwcF0KICAgIGFwcF9jb3JlX2NvbmZpZ1thcHAvY29yZS9jb25maWddIC0tPiB5YW1sW3lhbWxdCiAgICBhcHBfY29yZV9jb25maWdbYXBwL2NvcmUvY29uZmlnXSAtLT4gYXBwW2FwcF0KICAgIGFwcF9jb3JlX2NvbmZpZ1thcHAvY29yZS9jb25maWddIC0tPiB0b21sbGliW3RvbWxsaWJdCiAgICBhcHBfY29yZV9jb25maWdbYXBwL2NvcmUvY29uZmlnXSAtLT4gdG9tbGlbdG9tbGldCiAgICBhcHBfY29yZV9maXhfb3JjaGVzdHJhdG9yW2FwcC9jb3JlL2ZpeF9vcmNoZXN0cmF0b3JdIC0tPiBhcHBbYXBwXQogICAgYXBwX2NvcmVfcmVwb3J0X2dlbmVyYXRvclthcHAvY29yZS9yZXBvcnRfZ2VuZXJhdG9yXSAtLT4gYXBwW2FwcF0KICAgIGFwcF9jb3JlX3Rvb2xfcmVnaXN0cnlbYXBwL2NvcmUvdG9vbF9yZWdpc3RyeV0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfYXJjaGl0ZWN0dXJlX3Rvb2xbYXBwL3Rvb2xzL2FyY2hpdGVjdHVyZV90b29sXSAtLT4gYXN0W2FzdF0KICAgIGFwcF90b29sc19hcmNoaXRlY3R1cmVfdG9vbFthcHAvdG9vbHMvYXJjaGl0ZWN0dXJlX3Rvb2xdIC0tPiBhcHBbYXBwXQogICAgYXBwX3Rvb2xzX2NsZWFudXBfdG9vbFthcHAvdG9vbHMvY2xlYW51cF90b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19jb21wbGV4aXR5X3Rvb2xbYXBwL3Rvb2xzL2NvbXBsZXhpdHlfdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZGVhZGNvZGVfdG9vbFthcHAvdG9vbHMvZGVhZGNvZGVfdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IGFzdFthc3RdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IHJhcGlkZnV6eltyYXBpZGZ1enpdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZHVwbGljYXRpb25fdG9vbFthcHAvdG9vbHMvZHVwbGljYXRpb25fdG9vbF0gLS0+IGFzdG9yW2FzdG9yXQogICAgYXBwX3Rvb2xzX2VmZmljaWVuY3lfdG9vbFthcHAvdG9vbHMvZWZmaWNpZW5jeV90b29sXSAtLT4gYXN0W2FzdF0KICAgIGFwcF90b29sc19lZmZpY2llbmN5X3Rvb2xbYXBwL3Rvb2xzL2VmZmljaWVuY3lfdG9vbF0gLS0+IGFwcFthcHBdCiAgICBhcHBfdG9vbHNfZ2l0aWdub3JlX3Rvb2xbYXBwL3Rvb2xzL2dpdGlnbm9yZV90b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19naXRfdG9vbFthcHAvdG9vbHMvZ2l0X3Rvb2xdIC0tPiBhcHBbYXBwXQogICAgYXBwX3Rvb2xzX3NlY3JldHNfdG9vbFthcHAvdG9vbHMvc2VjcmV0c190b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19zZWN1cml0eV90b29sW2FwcC90b29scy9zZWN1cml0eV90b29sXSAtLT4gYXBwW2FwcF0KICAgIGFwcF90b29sc19zdHJ1Y3R1cmVfdG9vbFthcHAvdG9vbHMvc3RydWN0dXJlX3Rvb2xdIC0tPiBhcHBbYXBwXQogICAgYXBwX3Rvb2xzX3Rlc3RzX3Rvb2xbYXBwL3Rvb2xzL3Rlc3RzX3Rvb2xdIC0tPiBhcHBbYXBwXQ==)

## 📊 Detailed Findings
### 🛡️ Security (0 issues)
✅ No security issues found.

### 🧹 Code Quality & Hygiene
**💀 Dead Code / Unused (5 items)**
- `app\core\report_generator.py:12: unused import '_write_security_section' (90% confidence)`
- `app\main.py:12: unused import 'ReportResponse' (90% confidence)`
- `app\schemas.py:16: unused variable 'cls' (100% confidence)`
- `app\schemas.py:62: unused variable 'cls' (100% confidence)`
- `mcp_fastmcp_server.py:1170: unused variable 'dir' (100% confidence)`

**🤯 Complex Functions (Radon)**
| File | Function | Rank | Score |
|---|---|---|---|
| duplication_helper.py | run_duplication | C | 16 |
| mcp_fastmcp_server.py | generate_full_markdown_report | D | 27 |
| mcp_fastmcp_server.py | run_architecture_visualizer | D | 22 |
| mcp_fastmcp_server.py | run_auto_fix | C | 19 |
| mcp_fastmcp_server.py | run_duplication | C | 16 |
| mcp_fastmcp_server.py | run_tests_coverage | C | 15 |
| mcp_fastmcp_server.py | run_cleanup_scan | C | 14 |
| mcp_fastmcp_server.py | run_pip_audit | C | 13 |
| mcp_fastmcp_server.py | run_efficiency | C | 12 |
| mcp_fastmcp_server.py | run_secrets | C | 11 |
| mcp_fastmcp_server.py | run_dead_code | C | 11 |
| self_audit.py | run_self_audit | C | 16 |
| validate_dataset.py | validate_dataset | D | 23 |
| analyzer_agent.py | _calculate_score | D | 21 |
| analyzer_agent.py | analyze_project | C | 18 |
| report_generator.py | _write_top_issues_summary | C | 18 |
| report_generator.py | _write_enterprise_tests | C | 16 |
| report_generator.py | _write_top_action_roadmap | C | 13 |
| report_generator.py | _write_self_healing_section | C | 11 |
| report_generator.py | _write_mandatory_deadcode | C | 11 |

## 🎭 DUPLICATES (Grouped + Actionable)
**Found 6383 duplicated blocks.**
- **Hash:** `81e85647` (51 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:75`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:195`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:830`
  - ...and 2 more
- **Hash:** `4a572b0a` (39 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:66`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:185`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:263`
  - ...and 2 more
- **Hash:** `6f95a3f5` (39 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:67`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:186`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:264`
  - ...and 2 more
- **Hash:** `881acf70` (38 copies)
  - `.venv\Lib\site-packages\fastapi\applications.py:734`
  - `.venv\Lib\site-packages\fastapi\applications.py:1267`
  - `.venv\Lib\site-packages\fastapi\applications.py:1551`
  - ...and 2 more
- **Hash:** `7b60e182` (35 copies)
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:76`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:196`
  - `.venv\Lib\site-packages\rapidfuzz\fuzz_py.py:831`
  - ...and 2 more

**🗑️ Junk / Cleanup**
- **Total Reclaimable:** 64.96 MB
  - `__pycache__`: 301 items
  - `.pytest_cache`: 1 items
  - `htmlcov`: 1 items
  - `*.pyc`: 2612 items

### 🧪 Tests & Coverage
- **Coverage:** 33%
- **Passed:** 26 ✅
- **Failed:** 2 ❌

---
*Generated by Python Auditor MCP v2.1*